package org.ogasimli.bottomsheetdemo;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class MainFragment extends Fragment {

    private LinearLayout mBottomSheet;

    private LinearLayout llSsssss;

    private ImageView mLeftArrow;
    private CoordinatorLayout coordinator_layout;
    private ImageView mRightArrow;

    private ImageView ivTtttt;

    private Button button;
    private Button btnScale;
    private LockBottomSheetBehaviour bottomSheetBehavior;

    public MainFragment() {
        // Required empty public constructor
    }
    RelativeLayout imageView;
    public static MainFragment newInstance() {
        return new MainFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        // find container view
        mBottomSheet = view.findViewById(R.id.bottom_sheet);

        // find arrows
        mLeftArrow = view.findViewById(R.id.bottom_sheet_left_arrow);
        mRightArrow = view.findViewById(R.id.bottom_sheet_right_arrow);

        button = view.findViewById(R.id.button);
        btnScale = view.findViewById(R.id.btnScale);

        llSsssss = view.findViewById(R.id.ll_sssss);
        ivTtttt = view.findViewById(R.id.iv_ttttt);

        coordinator_layout = view.findViewById(R.id.coordinator_layout);

        //RelativeLayout.LayoutParams param = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, (int)convertDpToPixel(50, getContext()));

        //param.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        //coordinator_layout.setLayoutParams(param);


        initializeBottomSheet();
        imageView  = mBottomSheet.findViewById(R.id.imageView);

        imageView.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });


        button.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                RelativeLayout.LayoutParams param = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                param.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                coordinator_layout.setLayoutParams(param);

                bottomSheetBehavior.setState(LockBottomSheetBehaviour.STATE_EXPANDED);
                return false;
            }
        });

        btnScale.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {


                return false;
            }
        });

        return view;
    }

    public static float convertDpToPixel(float dp, Context context) {
        return dp * ((float) context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }

    public static float convertPixelsToDp(float px, Context context) {
        return px / ((float) context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }

    private void initializeBottomSheet() {

        // init the bottom sheet behavior
        bottomSheetBehavior = (LockBottomSheetBehaviour) LockBottomSheetBehaviour.from(mBottomSheet);

        // change the state of the bottom sheet
        bottomSheetBehavior.setState(LockBottomSheetBehaviour.STATE_COLLAPSED);

        // change the state of the bottom sheet
        //bottomSheetBehavior.setState(LockBottomSheetBehaviour.STATE_COLLAPSED);


        bottomSheetBehavior.setAllowUserDragging(false);
        // set callback for changes
        bottomSheetBehavior.setBottomSheetCallback(new LockBottomSheetBehaviour.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {

                if(newState == LockBottomSheetBehaviour.STATE_EXPANDED)
                {

                }
                else if(newState == LockBottomSheetBehaviour.STATE_COLLAPSED)
                {
                    //bottomSheetBehavior.setState(LockBottomSheetBehaviour.STATE_HIDDEN);
                    RelativeLayout.LayoutParams param = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, (int)convertDpToPixel(0, getContext()));
                    param.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                    coordinator_layout.setLayoutParams(param);
                }
                else if(newState == LockBottomSheetBehaviour.STATE_HIDDEN)
                {

                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                if (isAdded()) {
                    transitionBottomSheetBackgroundColor(slideOffset);
                    animateBottomSheetArrows(slideOffset);
                }
            }
        });


       /* imageView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        bottomSheetBehavior.setAllowUserDragging(false);
                        break;
                    case MotionEvent.ACTION_UP:
                        behavior.setAllowUserDragging(true);
                        break;
                }
                return true;

                return false;
            }
        });*/
    }

    private void transitionBottomSheetBackgroundColor(float slideOffset) {
        int colorFrom = getResources().getColor(android.R.color.transparent);
        int colorTo = getResources().getColor(R.color.colorxxx);
      //  mBottomSheet.setBackgroundColor(interpolateColor(slideOffset,
       //         colorFrom, colorTo));


        ivTtttt.setBackgroundColor(interpolateColor(slideOffset,
                colorFrom, colorTo));
    }

    private void animateBottomSheetArrows(float slideOffset) {
        mLeftArrow.setRotation(slideOffset * -180);
        mRightArrow.setRotation(slideOffset * 180);
    }

    // Helper method to interpolate colors
    private int interpolateColor(float fraction, int startValue, int endValue) {
        int startA = (startValue >> 24) & 0xff;
        int startR = (startValue >> 16) & 0xff;
        int startG = (startValue >> 8) & 0xff;
        int startB = startValue & 0xff;
        int endA = (endValue >> 24) & 0xff;
        int endR = (endValue >> 16) & 0xff;
        int endG = (endValue >> 8) & 0xff;
        int endB = endValue & 0xff;
        return ((startA + (int) (fraction * (endA - startA))) << 24) |
                ((startR + (int) (fraction * (endR - startR))) << 16) |
                ((startG + (int) (fraction * (endG - startG))) << 8) |
                ((startB + (int) (fraction * (endB - startB))));
    }
}
