package com.example.termini.tabexample;

import android.content.Context;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    //private final int FRAGMENT1 = 1;
    //private final int FRAGMENT2 = 2;

    private Button bt_tab1, bt_tab2;
    private List<Travel> listTravel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout linearLayout = findViewById(R.id.linearLayout);


        Travel travel = new Travel("kakak", 1);
        Travel travel2 = new Travel("kakak2222", 2);
        listTravel = new ArrayList<Travel>();
        listTravel.add(travel);
        listTravel.add(travel2);

        for(int i = 0; i < listTravel.size(); i++) {
            ImageButton iv = new ImageButton(this);
            iv.setId(i);

            LinearLayout.LayoutParams param = new LinearLayout.LayoutParams((int) convertDpToPixel(100, this), (int) convertDpToPixel(40, this));

            iv.setLayoutParams(param);

            iv.setOnClickListener(this);

            linearLayout.addView(iv);
        }
        // 위젯에 대한 참조
      /*  bt_tab1 = (Button)findViewById(R.id.bt_tab1);
        bt_tab2 = (Button)findViewById(R.id.bt_tab2);



        // 탭 버튼에 대한 리스너 연결
        bt_tab1.setOnClickListener(this);
        bt_tab2.setOnClickListener(this);*/

        // 임의로 액티비티 호출 시점에 어느 프레그먼트를 프레임레이아웃에 띄울 것인지를 정함
        //Travel travel = new Travel("kakak", 1);
        callFragment(listTravel.get(0));


    }

    @Override
    public void onClick(View v) {

        callFragment(listTravel.get(v.getId()));
        /*switch (v.getId()){
            case R.id.bt_tab1 :
                // '버튼1' 클릭 시 '프래그먼트1' 호출

                Travel travel = new Travel("kakak", 1);


                callFragment(listTravel);
                break;

            case R.id.bt_tab2 :
                // '버튼2' 클릭 시 '프래그먼트2' 호출
                Travel travel2 = new Travel("kakak2222", 2);
                callFragment(travel2);
                break;
        }*/
    }

    private void callFragment(Travel frament_no) {

        // 프래그먼트 사용을 위해
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();


        transaction.replace(R.id.fragment_container, Fragment1.newInstance(frament_no));
        transaction.commit();

    }


    public static float convertDpToPixel(float dp, Context context) {
        return dp * ((float) context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }

    public static float convertPixelsToDp(float px, Context context) {
        return px / ((float) context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }
}
