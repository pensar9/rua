package com.example.termini.tabexample;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment1 extends Fragment {
    static final String ARG_TRAVEL = "ARG_TRAVEL";
    Travel travel;


    public Fragment1() {
        // Required empty public constructor
    }

    public static Fragment1 newInstance(Travel travel) {
        Fragment1 fragment1 = new Fragment1();

        Bundle args = new Bundle();
        args.putParcelable(ARG_TRAVEL, travel);
        fragment1.setArguments(args);

        return fragment1;
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_fragment1, container, false);

       TextView tv =  view.findViewById(R.id.tv);

        tv.setText(travel.getName());

        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            travel = args.getParcelable(ARG_TRAVEL);
        }
    }
}