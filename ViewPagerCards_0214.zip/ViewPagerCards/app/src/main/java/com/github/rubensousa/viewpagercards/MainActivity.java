package com.github.rubensousa.viewpagercards;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener,
        CompoundButton.OnCheckedChangeListener {

    private Button mButton;
    private ViewPager mViewPager;

    private CardPagerAdapter mCardAdapter;
    private ShadowTransformer mCardShadowTransformer;
    private CardFragmentPagerAdapter mFragmentCardAdapter;
    private ShadowTransformer mFragmentCardShadowTransformer;

    private TextView title;
    private TextView calledBy;
    private boolean mShowingFragments = false;
    private String[] str = {"교통", "민수", "플래티넘", "시계"};
    private String[] str2 = {"곰", "여유", "사자", "호랑이"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mViewPager = (ViewPager) findViewById(R.id.viewPager);
        mButton = (Button) findViewById(R.id.cardTypeBtn);
        title = (TextView)findViewById(R.id.title);
        calledBy = (TextView)findViewById(R.id.calledBy);
        ((CheckBox) findViewById(R.id.checkBox)).setOnCheckedChangeListener(this);
        mButton.setOnClickListener(this);

        mCardAdapter = new CardPagerAdapter();
        mCardAdapter.addCardItem(new CardItem(R.string.title_1, R.string.text_1));
        mCardAdapter.addCardItem(new CardItem(R.string.title_2, R.string.text_1));
        mCardAdapter.addCardItem(new CardItem(R.string.title_3, R.string.text_1));
        mCardAdapter.addCardItem(new CardItem(R.string.title_4, R.string.text_1));
        mFragmentCardAdapter = new CardFragmentPagerAdapter(getSupportFragmentManager(),
                dpToPixels(2, this));

        mCardShadowTransformer = new ShadowTransformer(mViewPager, mCardAdapter);
        mFragmentCardShadowTransformer = new ShadowTransformer(mViewPager, mFragmentCardAdapter);

        mViewPager.setAdapter(mCardAdapter);
        mViewPager.setPageTransformer(false, mCardShadowTransformer);
        mViewPager.setOffscreenPageLimit(3);


        //추가
        mButton.setText("Fragments");
        mViewPager.setAdapter(mCardAdapter);
        mViewPager.setPageTransformer(false, mCardShadowTransformer);
        mViewPager.setPageMargin(60);

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                Log.d("kiki", "position:"+position+",positionOffset:"+positionOffset+"positionOffsetPixels:"+positionOffsetPixels);



                if(positionOffset == 0.0f) {
                    Log.d("kiki", "#9");
                    title.setText(str[position]);
                    title.setAlpha(1);

                    calledBy.setText(str2[position]);
                    calledBy.setAlpha(1);
                }
                else if(positionOffset > 0 && positionOffset < 0.5) {
                    Log.d("kiki", "#10");
                    title.setText(str[position]);
                    title.setAlpha(1 - positionOffset * 2);

                    calledBy.setText(str2[position]);
                    calledBy.setAlpha(1 - positionOffset * 2);
                }
                else {
                    Log.d("kiki", "#11");
                    title.setText(str[position+1]);
                    title.setAlpha((positionOffset - 0.5f) * 2);

                    calledBy.setText(str2[position+1]);
                    calledBy.setAlpha((positionOffset - 0.5f) * 2);
                }
            }

            @Override
            public void onPageSelected(int position) {

             /*   if(position == 0)
                    title.setText("교통카드");
                else if(position == 1)
                    title.setText("고슴도치");*/
                Log.d("kiki", "#2 position:"+position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

               // if(state == ViewPager.SCROLL_STATE_IDLE)

                Log.d("kiki", "#3 state:"+state);

            }
        });

        //추가
            mCardShadowTransformer.enableScaling(true);
        mFragmentCardShadowTransformer.enableScaling(true);
    }

    @Override
    public void onClick(View view) {
        if (!mShowingFragments) {
            mButton.setText("Views");
            mViewPager.setAdapter(mFragmentCardAdapter);
            mViewPager.setPageTransformer(false, mFragmentCardShadowTransformer);
        } else {
            mButton.setText("Fragments");
            mViewPager.setAdapter(mCardAdapter);
            mViewPager.setPageTransformer(false, mCardShadowTransformer);
        }

        mShowingFragments = !mShowingFragments;
    }

    public static float dpToPixels(int dp, Context context) {
        return dp * (context.getResources().getDisplayMetrics().density);
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        mCardShadowTransformer.enableScaling(b);
        mFragmentCardShadowTransformer.enableScaling(b);
    }
}
