package com.example.ponyo.kookmingraph;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity implements
        View.OnClickListener {

    private TextView card;
    private RelativeLayout frameLayout;
    private Button mPlayView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        mPlayView = findViewById(R.id.button);
        frameLayout = (RelativeLayout) findViewById(R.id.fragment_animation_frame);
        card = (TextView) findViewById(R.id.imgTarget);
        mPlayView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
//        new SlideInAnimation(card).setDirection(Animation.DIRECTION_UP)
//                .animate();

        new SlideInUnderneathAnimation(card).setDirection(
                Animation.DIRECTION_UP).animate();
       // isFinished = true;
    }
}
