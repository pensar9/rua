package com.example.ponyo.kookmingraph;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.ChangeBounds;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnticipateOvershootInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Context mContext;
    private Activity mActivity;

    private static final String TAG = MainActivity.class.getSimpleName();

    private RelativeLayout mCLayout;
    private Button mButton;
    private Button mButton2;
    private View mViewBox;
    private TextView textView2;
    private TextView textView;
    private RelativeLayout rlTest;

    private boolean isBig = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get the application context
        mContext = getApplicationContext();
        mActivity = MainActivity.this;

        // Get the widget reference from XML layout
        mCLayout = (RelativeLayout) findViewById(R.id.coordinator_layout);
        mButton = (Button) findViewById(R.id.btn);
        mButton2 = (Button) findViewById(R.id.button);
        mViewBox = (View) findViewById(R.id.view_box);
        textView2 = findViewById(R.id.textView2);
        textView = findViewById(R.id.textView);

        rlTest =  findViewById(R.id.rl_test);

       // mViewBox.getLayoutParams().width = 400;
       // mViewBox.getLayoutParams().height = 100;

        // Set a click listener for button
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // new SlideInUnderneathAnimation(textView2).setDirection(
                //        Animation.DIRECTION_UP).animate();


                /*
                    ChangeBounds
                        This transition captures the layout bounds of target views before and after
                        the scene change and animates those changes during the transition.
                */

           // Initialize a new ChangeBounds transition instance
                ChangeBounds changeBounds = new ChangeBounds();

                // Set the transition start delay
                changeBounds.setStartDelay(300);

                // Set the transition interpolator
                changeBounds.setInterpolator(new AnticipateOvershootInterpolator());

                // Specify the transition duration
                changeBounds.setDuration(1000);



                changeBounds.addListener(new Transition.TransitionListener() {
                    @Override
                    public void onTransitionStart(Transition transition) {

                    }

                    @Override
                    public void onTransitionEnd(Transition transition) {

                        //textView2.setVisibility(TextView.VISIBLE);
                      if(!isBig) {
                          new FadeInAnimation(textView2).setDuration(300).animate();
                         /* Log.d("zzzzz", "#1");
                          SlideInUnderneathAnimation slideInUnderneathAnimation = new SlideInUnderneathAnimation(textView2);

                          slideInUnderneathAnimation.setDirection(
                                  Animation.DIRECTION_UP).setListener(new AnimationListener() {


                              @Override
                              public void onAnimationEnd(Animation animation) {
                                  Log.d("zzzzz", "#3");
                                  textView2.setVisibility(TextView.VISIBLE);
                              }
                          }).animate();*/

                      }
                     /* else
                      {
                          //textView2.setVisibility(TextView.INVISIBLE);
                          SlideOutUnderneathAnimation slideOutUnderneathAnimation = new SlideOutUnderneathAnimation(textView2);

                          slideOutUnderneathAnimation.setDirection(
                                  Animation.DIRECTION_UP).setListener(new AnimationListener() {


                              @Override
                              public void onAnimationEnd(Animation animation) {
                                  Log.d("zzzzz", "#3");
                                   textView2.setVisibility(TextView.INVISIBLE);
                              }
                          }).animate();
                      }*/

                    }

                    @Override
                    public void onTransitionCancel(Transition transition) {}

                    @Override
                    public void onTransitionPause(Transition transition) { }

                    @Override
                    public void onTransitionResume(Transition transition) { }
                });


                // Begin the delayed transition
                TransitionManager.beginDelayedTransition(mCLayout,changeBounds);

                if(!isBig) {
                    Log.d("zzzzz", "#2");
                   // textView2.setVisibility(TextView.INVISIBLE);
                }


                // Toggle the button size
               // toggleSize(mViewBox, mButton2);
                toggleSize2(rlTest);

                if(!isBig) {

                   //new FadeInAnimation(textView2).animate();

                   /* SlideInUnderneathAnimation slideInUnderneathAnimation = new SlideInUnderneathAnimation(textView2);

                    slideInUnderneathAnimation.setDirection(
                            Animation.DIRECTION_UP).setListener(new AnimationListener() {


                        @Override
                        public void onAnimationEnd(Animation animation) {
                            Log.d("zzzzz", "#3");
                            textView2.setVisibility(TextView.VISIBLE);
                        }
                    }).animate();*/

                }
                else
                {
                    new FadeOutAnimation(textView2).setDuration(300).animate();

                    //textView2.setVisibility(TextView.INVISIBLE);
                   /* SlideOutUnderneathAnimation slideOutUnderneathAnimation = new SlideOutUnderneathAnimation(textView2);

                    slideOutUnderneathAnimation.setDirection(
                            Animation.DIRECTION_UP).setListener(new AnimationListener() {


                        @Override
                        public void onAnimationEnd(Animation animation) {
                            Log.d("zzzzz", "#3");
                            textView2.setVisibility(TextView.INVISIBLE);
                        }
                    }).animate();*/
                }
/*
                // Initialize a new ChangeBounds transition instance
                ChangeBounds changeBounds2 = new ChangeBounds();

                // Set the transition start delay
                changeBounds2.setStartDelay(300);

                // Set the transition interpolator
                changeBounds2.setInterpolator(new AnticipateOvershootInterpolator());

                // Specify the transition duration
                changeBounds2.setDuration(1000);

                // Begin the delayed transition
                TransitionManager.beginDelayedTransition(mButton2,changeBounds2);*/
            }
        });
    }

    /**
     * This method converts device specific pixels to density independent pixels.
     *
     * @param px A value in px (pixels) unit. Which we need to convert into db
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent dp equivalent to px value
     */
    public static float convertPixelsToDp(float px, Context context){
        return px / ((float) context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }

    public static float convertDpToPixel(float dp, Context context){
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float px = dp * ((float)metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT);
        return px;
    }

    // Custom method to toggle view size
    protected void toggleSize(final View v, Button v2){
        ViewGroup.LayoutParams params = v.getLayoutParams();

        v.post(new Runnable() {

            @Override
            public void run() {
                int width = v.getWidth();
                int height = v.getHeight();
                //do something cool with width and height
            }

        });


        RelativeLayout.LayoutParams params2 = (RelativeLayout.LayoutParams)v2.getLayoutParams();
        if(isBig){
            //params.width = 400;
            //params.height = 100;

            params.width = (int)convertDpToPixel(20, this);
            params.height = (int)convertDpToPixel(20, this);

           // params2.setMarginStart(-30);
            params2.setMarginStart( - (int)convertDpToPixel(13, this));
            //params2.setMarginStart((int)convertDpToPixel(params2.width, this));

            isBig = false;

        }else {
            //params.width = ViewGroup.LayoutParams.MATCH_PARENT;
           // params.height = ViewGroup.LayoutParams.MATCH_PARENT;
            params.width = (int)convertDpToPixel(200, this);
            params.height = (int)convertDpToPixel(20, this);


           // params2.setMarginStart((int)convertDpToPixel(-1 * params2.width -20, this));
           // params2.setMarginStart(1 * params2.width - (int)convertDpToPixel(-13, this));
         //   params2.setMarginStart(1 * params2.width);
            params2.setMarginStart(-1 * v2.getWidth() - (int)convertDpToPixel(14, this));
            //params.width = 800;
            //params.height = 100;

            isBig = true;
        }
        v.setLayoutParams(params);
    }


    protected void toggleSize2(final RelativeLayout v){
        ViewGroup.LayoutParams params = v.getLayoutParams();



        v.post(new Runnable() {

            @Override
            public void run() {
                int width = v.getWidth();
                int height = v.getHeight();
                //do something cool with width and height
            }

        });


       // RelativeLayout.LayoutParams params2 = (RelativeLayout.LayoutParams)v2.getLayoutParams();
        if(isBig){
            //params.width = 400;
            //params.height = 100;

          //  params.width = (int)convertDpToPixel(20, this);
            params.height = (int)convertDpToPixel(150, this);
            ViewGroup.MarginLayoutParams s = (ViewGroup.MarginLayoutParams) params;
            s.setMargins((int)convertDpToPixel(40, this), 0, (int)convertDpToPixel(40, this), 0);
           // textView2.setVisibility(TextView.VISIBLE);

            // params2.setMarginStart(-30);
         //   params2.setMarginStart( - (int)convertDpToPixel(13, this));
            //params2.setMarginStart((int)convertDpToPixel(params2.width, this));


            ViewGroup.LayoutParams params2 = textView.getLayoutParams();
            ViewGroup.MarginLayoutParams s2 = (ViewGroup.MarginLayoutParams) params2;

            s2.setMargins(0, (int)convertDpToPixel(20, this), 0, 0);


            isBig = false;

        }else {
            //params.width = ViewGroup.LayoutParams.MATCH_PARENT;
            // params.height = ViewGroup.LayoutParams.MATCH_PARENT;
           // params.width = (int)convertDpToPixel(200, this);
            params.height = (int)convertDpToPixel(100, this);

            ViewGroup.MarginLayoutParams s = (ViewGroup.MarginLayoutParams) params;
            s.setMargins(0, 0, 0, 0);

           // textView2.setVisibility(TextView.GONE);

            // params2.setMarginStart((int)convertDpToPixel(-1 * params2.width -20, this));
            // params2.setMarginStart(1 * params2.width - (int)convertDpToPixel(-13, this));
            //   params2.setMarginStart(1 * params2.width);
         //   params2.setMarginStart(-1 * v2.getWidth() - (int)convertDpToPixel(14, this));
            //params.width = 800;
            //params.height = 100;

            ViewGroup.LayoutParams params2 = textView.getLayoutParams();
            ViewGroup.MarginLayoutParams s2 = (ViewGroup.MarginLayoutParams) params2;

            s2.setMargins(0, (int)convertDpToPixel(-20, this), 0, 0);



            isBig = true;
        }
        v.setLayoutParams(params);
    }
}
