package com.example.termini.buttontest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.Toast;

import at.markushi.ui.CircleButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private  RotateAnimation rotate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        findViewById(R.id.button0).setOnClickListener(this);
     //   rootView.findViewById(R.id.button1).setOnClickListener(this);
     //   rootView.findViewById(R.id.button2).setOnClickListener(this);

        final ImageView iv_rotate = findViewById(R.id.iv_rotate);


      //  iv_rotate.

         rotate = new RotateAnimation(0, 720, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(1000);
        rotate.setInterpolator(new DecelerateInterpolator());

      //  ImageView image= (ImageView) findViewById(R.id.imageView);


        CardView card = findViewById(R.id.card);

        iv_rotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(rotate);
            }
        });

        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getBaseContext(), "xx", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onClick(View v) {
       // Toast.makeText(this, "Button clicked", Toast.LENGTH_SHORT).show();
        v.startAnimation(rotate);
    }
}
