package com.example.termini.recyclerviewfooter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.termini.recyclerviewfooter.adapter.RecyclerViewAdapter;
import com.example.termini.recyclerviewfooter.entity.CardUsingHistory;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;

    private RecyclerViewAdapter mDynamicListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        mRecyclerView = findViewById(R.id.my_list);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        //add space item decoration and pass space you want to give
        //mRecyclerView.addItemDecoration(new Space(20));

      /*  firstList = Utilities.populateFirstList();
        secondList = Utilities.populateSecondList();

        // Initialize the list

        mDynamicListAdapter.setFirstList(firstList);
        mDynamicListAdapter.setSecondList(secondList);

        mLayoutManager = new LinearLayoutManager(MainActivity.this);
        mRecyclerView.setLayoutManager(mLayoutManager);*/

      List<CardUsingHistory> list = new ArrayList<>();

      list.add(new CardUsingHistory("xxxx1"));
        list.add(new CardUsingHistory("xxxx2"));
        list.add(new CardUsingHistory("xxxx3"));
        list.add(new CardUsingHistory("xxxx4"));
        list.add(new CardUsingHistory("xxxx5"));
        list.add(new CardUsingHistory("xxxx6"));


        mDynamicListAdapter = new RecyclerViewAdapter(this, list);


        mRecyclerView.setAdapter(mDynamicListAdapter);
    }
}
