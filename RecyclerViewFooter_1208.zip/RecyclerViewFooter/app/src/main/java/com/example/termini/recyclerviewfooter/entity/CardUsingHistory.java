package com.example.termini.recyclerviewfooter.entity;

public class CardUsingHistory {


    private String cardName;

    public CardUsingHistory(String cardName) {
        this.cardName = cardName;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }
}
